class RestaurantConst {
  static const String imageUrl = 'https://restaurant-api.dicoding.dev/images';
  static const String smallUrl = '/small';
  static const String mediumUrl = '/medium';
  static const String largeUrl = '/large';
}